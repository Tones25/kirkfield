var require = meteorInstall({"server":{"methods.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/methods.js                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.methods({                                                                                                      // 1
	addUser: function () {                                                                                               // 3
		function addUser(username, password) {                                                                              // 1
			if (Roles.userIsInRole(Meteor.user(), 'admin')) {                                                                  // 4
				if (Meteor.users.findOne({ username: username })) {                                                               // 5
					throw new Meteor.Error('Username already in use.');                                                              // 6
				} else {                                                                                                          // 7
					var id = Accounts.createUser({                                                                                   // 8
						username: username,                                                                                             // 9
						password: password                                                                                              // 10
					});                                                                                                              // 8
                                                                                                                      //
					Roles.setUserRoles(id, ['user']);                                                                                // 13
				}                                                                                                                 // 14
			}                                                                                                                  // 15
		}                                                                                                                   // 16
                                                                                                                      //
		return addUser;                                                                                                     // 1
	}(),                                                                                                                 // 1
	addInventoryItem: function () {                                                                                      // 18
		function addInventoryItem(inventoryItemId, inventoryItemName, unitPrice, inventoryItemQuantity, make, model, serialNum) {
			if (!Meteor.userId()) {                                                                                            // 19
				throw new Meteor.Error('You must be logged in.');                                                                 // 20
			}                                                                                                                  // 21
                                                                                                                      //
			entry = Inventory.findOne({ inventoryItemId: inventoryItemId });                                                   // 23
			//update quantity if item exists, add new listing if not                                                           // 24
			if (entry) {                                                                                                       // 25
				newQuantity = parseInt(entry.inventoryItemQuantity) + parseInt(inventoryItemQuantity);                            // 26
				Inventory.update({ _id: entry._id }, { $set: { inventoryItemQuantity: newQuantity } });                           // 27
			} else {                                                                                                           // 31
				Inventory.insert({                                                                                                // 32
					inventoryItemId: inventoryItemId,                                                                                // 33
					inventoryItemName: inventoryItemName,                                                                            // 34
					unitPrice: parseFloat(unitPrice),                                                                                // 35
					inventoryItemQuantity: parseInt(inventoryItemQuantity),                                                          // 36
					make: make,                                                                                                      // 37
					model: model,                                                                                                    // 38
					serialNum: serialNum,                                                                                            // 39
					createdAt: new Date(),                                                                                           // 40
					user: Meteor.userId()                                                                                            // 41
				});                                                                                                               // 32
			}                                                                                                                  // 43
		}                                                                                                                   // 44
                                                                                                                      //
		return addInventoryItem;                                                                                            // 1
	}(),                                                                                                                 // 1
	editInventoryItem: function () {                                                                                     // 46
		function editInventoryItem(inventoryItem, inventoryItemName, unitPrice, inventoryItemQuantity, make, model, serialNum) {
			if (!Meteor.userId()) {                                                                                            // 47
				throw new Meteor.Error('You must be logged in.');                                                                 // 48
			}                                                                                                                  // 49
			entry = Inventory.findOne({ _id: inventoryItem._id });                                                             // 50
			if (entry) {                                                                                                       // 51
				Inventory.update({ _id: entry._id }, { $set: {                                                                    // 52
						inventoryItemName: inventoryItemName,                                                                           // 55
						unitPrice: unitPrice,                                                                                           // 56
						inventoryItemQuantity: inventoryItemQuantity,                                                                   // 57
						make: make,                                                                                                     // 58
						model: model,                                                                                                   // 59
						serialNum: serialNum                                                                                            // 60
					} });                                                                                                            // 54
			} else {                                                                                                           // 63
				throw new Meteor.Error('Invalid ID');                                                                             // 64
			}                                                                                                                  // 65
		}                                                                                                                   // 66
                                                                                                                      //
		return editInventoryItem;                                                                                           // 1
	}(),                                                                                                                 // 1
	deleteInventoryItem: function () {                                                                                   // 68
		function deleteInventoryItem(inventoryItem) {                                                                       // 1
			//can only delete items user inserted                                                                              // 69
			//might have to change                                                                                             // 70
			if (!Meteor.userId()) {                                                                                            // 71
				throw new Meteor.Error('You must be logged in.');                                                                 // 72
			}                                                                                                                  // 73
			Inventory.remove(inventoryItem._id);                                                                               // 74
		}                                                                                                                   // 75
                                                                                                                      //
		return deleteInventoryItem;                                                                                         // 1
	}(),                                                                                                                 // 1
	addJob: function () {                                                                                                // 77
		function addJob(invoice, complete, date, customer, jobTypeCode, estimateCost, estimateEmployee, installCost, installations, installEmployee, vehicleId, mileage, comments) {
			if (!Meteor.userId()) {                                                                                            // 81
				throw new Meteor.Error('You must be logged in.');                                                                 // 82
			}                                                                                                                  // 83
			entry = Jobs.findOne({ invoice: parseInt(invoice) });                                                              // 84
			if (entry) {                                                                                                       // 85
				throw new Meteor.Error('Duplicate invoice');                                                                      // 86
			}                                                                                                                  // 87
			cust = Customers.findOne({ customerId: parseInt(customer) });                                                      // 88
			if (!cust) throw new Meteor.Error('Invalid Customer');                                                             // 89
			emp = Employees.findOne({ employeeId: parseInt(installEmployee) });                                                // 90
			if (!emp) throw new Meteor.Error('Invalid Employee');                                                              // 91
			var dateTokens = date.split("-");                                                                                  // 92
			var dateYear = parseInt(dateTokens[0]);                                                                            // 93
			var dateMonth = parseInt(dateTokens[1]) - 1; //BSON month is 0 based                                               // 94
			var dateDay = parseInt(dateTokens[2]);                                                                             // 95
			var cName = cust.contactName || '';                                                                                // 96
			var cAddr = cust.address || '';                                                                                    // 97
			var cPhn1 = cust.phone1 || '';                                                                                     // 98
			var cPhn2 = cust.phone2 || '';                                                                                     // 99
			var empName = emp.employeeFirstName || '';                                                                         // 100
			console.log(installations[0].item);                                                                                // 101
                                                                                                                      //
			Jobs.insert({                                                                                                      // 103
				invoice: parseInt(invoice),                                                                                       // 104
				complete: complete,                                                                                               // 105
				date: new Date(dateYear, dateMonth, dateDay),                                                                     // 106
				customer: customer,                                                                                               // 107
				cName: cName,                                                                                                     // 108
				cAddr: cAddr,                                                                                                     // 109
				cPhn1: cPhn1,                                                                                                     // 110
				cPhn2: cPhn2,                                                                                                     // 111
				jobTypeCode: jobTypeCode,                                                                                         // 112
				estimateCost: parseFloat(estimateCost),                                                                           // 113
				estimateEmployee: parseInt(estimateEmployee),                                                                     // 114
				installCost: parseFloat(installCost),                                                                             // 115
				installations: installations,                                                                                     // 116
				installEmployee: installEmployee,                                                                                 // 117
				empName: empName,                                                                                                 // 118
				vehicleId: vehicleId,                                                                                             // 119
				mileage: parseInt(mileage),                                                                                       // 120
				comments: comments,                                                                                               // 121
				createdAt: new Date(),                                                                                            // 122
				user: Meteor.userId()                                                                                             // 123
			});                                                                                                                // 103
			//Decrease stock quantity of job's installed items                                                                 // 125
			if (installations[0].item != null) {                                                                               // 126
				for (var i = 0; i < installations.length; i++) {                                                                  // 127
                                                                                                                      //
					entry = Inventory.findOne({ inventoryItemId: parseInt(installations[i].item) });                                 // 129
					if (entry) {                                                                                                     // 130
						var quant = installations[i].quantity || 1;                                                                     // 131
						console.log(quant);                                                                                             // 132
						newQuantity = entry.inventoryItemQuantity - quant;                                                              // 133
						Inventory.update({ _id: entry._id }, { $set: { inventoryItemQuantity: newQuantity } });                         // 134
					}                                                                                                                // 138
				}                                                                                                                 // 139
			}                                                                                                                  // 140
		}                                                                                                                   // 141
                                                                                                                      //
		return addJob;                                                                                                      // 1
	}(),                                                                                                                 // 1
	editJobItem: function () {                                                                                           // 143
		function editJobItem(job, complete, date, customer, jobTypeCode, estimateCost, estimateEmployee, installCost, installations, installEmployee, vehicleId, mileage, comments) {
			if (!Meteor.userId()) {                                                                                            // 147
				throw new Meteor.Error('You must be logged in.');                                                                 // 148
			}                                                                                                                  // 149
			entry = Jobs.findOne({ _id: job._id });                                                                            // 150
			if (entry) {                                                                                                       // 151
				cust = Customers.findOne({ customerId: parseInt(customer) });                                                     // 152
				if (!cust) throw new Meteor.Error('Invalid Customer');                                                            // 153
				emp = Employees.findOne({ employeeId: parseInt(installEmployee) });                                               // 154
				if (!emp) throw new Meteor.Error('Invalid Employee');                                                             // 155
				var oldInstalls = entry.installations;                                                                            // 156
				var dateTokens = date.split("-");                                                                                 // 157
				var dateYear = parseInt(dateTokens[0]);                                                                           // 158
				var dateMonth = parseInt(dateTokens[1]) - 1; //BSON month is 0 based                                              // 159
				var dateDay = parseInt(dateTokens[2]);                                                                            // 160
				Jobs.update({ _id: entry._id }, { $set: {                                                                         // 161
						complete: complete,                                                                                             // 164
						date: new Date(dateYear, dateMonth, dateDay),                                                                   // 165
						customer: customer,                                                                                             // 166
						cName: cust.contactName,                                                                                        // 167
						cAddr: cust.address,                                                                                            // 168
						cPhn1: cust.phone1,                                                                                             // 169
						cPhn2: cust.phone2,                                                                                             // 170
						jobTypeCode: jobTypeCode,                                                                                       // 171
						estimateCost: parseFloat(estimateCost),                                                                         // 172
						estimateEmployee: parseInt(estimateEmployee),                                                                   // 173
						installCost: parseFloat(installCost),                                                                           // 174
						installations: installations,                                                                                   // 175
						installEmployee: parseInt(installEmployee),                                                                     // 176
						empName: emp.employeeFirstName,                                                                                 // 177
						vehicleId: vehicleId,                                                                                           // 178
						mileage: parseInt(mileage),                                                                                     // 179
						comments: comments                                                                                              // 180
					} });                                                                                                            // 163
                                                                                                                      //
				if (oldInstalls != installations) {                                                                               // 183
					//Restore stock from the previous version of the job                                                             // 184
					for (var i = 0; i < oldInstalls.length; i++) {                                                                   // 185
						entry = Inventory.findOne({ inventoryItemId: parseInt(oldInstalls[i].item) });                                  // 186
						if (entry) {                                                                                                    // 187
							var quant = parseInt(oldInstalls[i].quantity) || 1;                                                            // 188
							newQuantity = entry.inventoryItemQuantity + quant;                                                             // 189
							Inventory.update({ _id: entry._id }, { $set: { inventoryItemQuantity: newQuantity } });                        // 190
						}                                                                                                               // 194
					}                                                                                                                // 195
                                                                                                                      //
					//Decrease stock quantity of job's new installations                                                             // 197
					if (installations[0].item) {                                                                                     // 198
						for (var i = 0; i < installations.length; i++) {                                                                // 199
							entry = Inventory.findOne({ inventoryItemId: parseInt(installations[i].item) });                               // 200
							if (entry) {                                                                                                   // 201
								//console.log(installQts[i])                                                                                  // 202
								var _quant = installations[i].quantity || 1;                                                                  // 203
								//console.log(quant)                                                                                          // 204
								newQuantity = entry.inventoryItemQuantity - _quant;                                                           // 205
								Inventory.update({ _id: entry._id }, { $set: { inventoryItemQuantity: newQuantity } });                       // 206
							}                                                                                                              // 210
						}                                                                                                               // 211
					}                                                                                                                // 212
				}                                                                                                                 // 213
			} else {                                                                                                           // 215
				throw new Meteor.Error('Invalid ID');                                                                             // 216
			}                                                                                                                  // 217
		}                                                                                                                   // 218
                                                                                                                      //
		return editJobItem;                                                                                                 // 1
	}(),                                                                                                                 // 1
	deleteJobItem: function () {                                                                                         // 220
		function deleteJobItem(job) {                                                                                       // 1
			if (!Meteor.userId()) {                                                                                            // 221
				throw new Meteor.Error('You must be logged in.');                                                                 // 222
			}                                                                                                                  // 223
			var installIds = job.installations;                                                                                // 224
			Jobs.remove(job._id);                                                                                              // 225
			//Restore stock quantity of the deleted job's installed items                                                      // 226
			for (var i = 0; i < installIds.length; i++) {                                                                      // 227
				entry = Inventory.findOne({ inventoryItemId: parseInt(installIds[i].item) });                                     // 228
				//console.log(installQts[i])                                                                                      // 229
				var quant = parseInt(installIds[i].quantity) || 1;                                                                // 230
				//console.log(quant)                                                                                              // 231
				newQuantity = entry.inventoryItemQuantity + quant;                                                                // 232
				Inventory.update({ _id: entry._id }, { $set: { inventoryItemQuantity: newQuantity } });                           // 233
			}                                                                                                                  // 237
		}                                                                                                                   // 238
                                                                                                                      //
		return deleteJobItem;                                                                                               // 1
	}(),                                                                                                                 // 1
	addVehicle: function () {                                                                                            // 240
		function addVehicle(vehicleId, vehicleMake, vehicleModel, vehicleModelYear, licensePlate, color, driver, initialMileage, repairHist, description, lastOil, nextOil) {
			if (!Meteor.userId()) {                                                                                            // 244
				throw new Meteor.Error('You must be logged in.');                                                                 // 245
			}                                                                                                                  // 246
			entry = Vehicles.findOne({ vehicleId: parseInt(vehicleId) });                                                      // 247
			if (entry) {                                                                                                       // 248
				throw new Meteor.Error('Duplicate id');                                                                           // 249
			}                                                                                                                  // 250
			emp = Employees.findOne({ employeeId: parseInt(driver) });                                                         // 251
			if (!emp) throw new Meteor.Error('Invalid Employee');                                                              // 252
			var dateTokens = lastOil.split("-");                                                                               // 253
			var dateYear = parseInt(dateTokens[0]);                                                                            // 254
			var dateMonth = parseInt(dateTokens[1]) - 1; //BSON month is 0 based                                               // 255
			var dateDay = parseInt(dateTokens[2]);                                                                             // 256
			var lOil = new Date(dateYear, dateMonth, dateDay);                                                                 // 257
			var dateTokens2 = nextOil.split("-");                                                                              // 258
			var dateYear2 = parseInt(dateTokens2[0]);                                                                          // 259
			var dateMonth2 = parseInt(dateTokens2[1]) - 1; //BSON month is 0 based                                             // 260
			var dateDay2 = parseInt(dateTokens2[2]);                                                                           // 261
			var nOil = new Date(dateYear2, dateMonth2, dateDay2);                                                              // 262
			Vehicles.insert({                                                                                                  // 263
				vehicleId: vehicleId,                                                                                             // 264
				vehicleMake: vehicleMake,                                                                                         // 265
				vehicleModel: vehicleModel,                                                                                       // 266
				vehicleModelYear: vehicleModelYear,                                                                               // 267
				licensePlate: licensePlate,                                                                                       // 268
				color: color,                                                                                                     // 269
				driver: parseInt(driver),                                                                                         // 270
				driverName: emp.employeeFirstName,                                                                                // 271
				initialMileage: initialMileage,                                                                                   // 272
				description: description,                                                                                         // 273
				repairHist: repairHist,                                                                                           // 274
				lastOil: lOil,                                                                                                    // 275
				nextOil: nOil,                                                                                                    // 276
				createdAt: new Date(),                                                                                            // 277
				user: Meteor.userId()                                                                                             // 278
			});                                                                                                                // 263
		}                                                                                                                   // 280
                                                                                                                      //
		return addVehicle;                                                                                                  // 1
	}(),                                                                                                                 // 1
	editVehicle: function () {                                                                                           // 282
		function editVehicle(vehicle, vehicleMake, vehicleModel, vehicleModelYear, licensePlate, color, driver, initialMileage, repairHist, description, lastOil, nextOil) {
			if (!Meteor.userId()) {                                                                                            // 286
				throw new Meteor.Error('You must be logged in.');                                                                 // 287
			}                                                                                                                  // 288
			entry = Vehicles.findOne({ _id: vehicle._id });                                                                    // 289
			if (entry) {                                                                                                       // 290
				emp = Employees.findOne({ employeeId: parseInt(driver) });                                                        // 291
				if (!emp) throw new Meteor.Error('Invalid Employee');                                                             // 292
				var dateTokens = lastOil.split("-");                                                                              // 293
				var dateYear = parseInt(dateTokens[0]);                                                                           // 294
				var dateMonth = parseInt(dateTokens[1]) - 1; //BSON month is 0 based                                              // 295
				var dateDay = parseInt(dateTokens[2]);                                                                            // 296
				var lOil = new Date(dateYear, dateMonth, dateDay);                                                                // 297
				var dateTokens2 = nextOil.split("-");                                                                             // 298
				var dateYear2 = parseInt(dateTokens2[0]);                                                                         // 299
				var dateMonth2 = parseInt(dateTokens2[1]) - 1; //BSON month is 0 based                                            // 300
				var dateDay2 = parseInt(dateTokens2[2]);                                                                          // 301
				var nOil = new Date(dateYear2, dateMonth2, dateDay2);                                                             // 302
				Vehicles.update({ _id: entry._id }, { $set: {                                                                     // 303
						vehicleMake: vehicleMake,                                                                                       // 306
						vehicleModel: vehicleModel,                                                                                     // 307
						vehicleModelYear: vehicleModelYear,                                                                             // 308
						licensePlate: licensePlate,                                                                                     // 309
						color: color,                                                                                                   // 310
						driver: parseInt(driver),                                                                                       // 311
						driverName: emp.employeeFirstName,                                                                              // 312
						initialMileage: initialMileage,                                                                                 // 313
						description: description,                                                                                       // 314
						repairHist: repairHist,                                                                                         // 315
						lastOil: lOil,                                                                                                  // 316
						nextOil: nOil                                                                                                   // 317
					} });                                                                                                            // 305
			}                                                                                                                  // 319
		}                                                                                                                   // 319
                                                                                                                      //
		return editVehicle;                                                                                                 // 1
	}(),                                                                                                                 // 1
	deleteVehicle: function () {                                                                                         // 321
		function deleteVehicle(vehicle) {                                                                                   // 1
			//can only delete vehicles user inserted                                                                           // 322
			//might have to change                                                                                             // 323
			if (!Meteor.userId()) {                                                                                            // 324
				throw new Meteor.Error('You must be logged in.');                                                                 // 325
			}                                                                                                                  // 326
			Vehicles.remove(vehicle._id);                                                                                      // 327
		}                                                                                                                   // 328
                                                                                                                      //
		return deleteVehicle;                                                                                               // 1
	}(),                                                                                                                 // 1
	addEmployee: function () {                                                                                           // 330
		function addEmployee(employeeId, employeeFirstName, employeeLastName, employeeStartDate, employeeExperience, employeeHourlyRate) {
			if (!Meteor.userId()) {                                                                                            // 332
				throw new Meteor.Error('You must be logged in.');                                                                 // 333
			}                                                                                                                  // 334
			entry = Employees.findOne({ employeeId: employeeId });                                                             // 335
			if (entry) {                                                                                                       // 336
				throw new Meteor.Error('Duplicate id');                                                                           // 337
			}                                                                                                                  // 338
			if (employeeFirstName.length < 1) throw new Meteor.Error('Name cannot be blank.');                                 // 339
                                                                                                                      //
			var dateTokens = employeeStartDate.split("-");                                                                     // 341
			var dateYear = parseInt(dateTokens[0]);                                                                            // 342
			var dateMonth = parseInt(dateTokens[1]) - 1; //BSON month is 0 based                                               // 343
			var dateDay = parseInt(dateTokens[2]);                                                                             // 344
                                                                                                                      //
			Employees.insert({                                                                                                 // 346
				employeeId: employeeId,                                                                                           // 347
				employeeFirstName: employeeFirstName,                                                                             // 348
				employeeLastName: employeeLastName,                                                                               // 349
				employeeStartDate: new Date(dateYear, dateMonth, dateDay),                                                        // 350
				employeeEndDate: null,                                                                                            // 351
				employeeExperience: employeeExperience,                                                                           // 352
				employeeHourlyRate: employeeHourlyRate,                                                                           // 353
				createdAt: new Date(),                                                                                            // 354
				user: Meteor.userId()                                                                                             // 355
			});                                                                                                                // 346
		}                                                                                                                   // 357
                                                                                                                      //
		return addEmployee;                                                                                                 // 1
	}(),                                                                                                                 // 1
	editEmployee: function () {                                                                                          // 359
		function editEmployee(employee, employeeFirstName, employeeLastName, employeeStartDate, employeeExperience, employeeHourlyRate) {
			if (!Meteor.userId()) {                                                                                            // 361
				throw new Meteor.Error('You must be logged in.');                                                                 // 362
			}                                                                                                                  // 363
			entry = Employees.findOne({ _id: employee._id });                                                                  // 364
			if (!entry) {                                                                                                      // 365
				throw new Meteor.Error('Invalid id');                                                                             // 366
			}                                                                                                                  // 367
			if (employeeFirstName.length < 1) throw new Meteor.Error('Name cannot be blank.');                                 // 368
                                                                                                                      //
			var dateTokens = employeeStartDate.split("-");                                                                     // 370
			var dateYear = parseInt(dateTokens[0]);                                                                            // 371
			var dateMonth = parseInt(dateTokens[1]) - 1; //BSON month is 0 based                                               // 372
			var dateDay = parseInt(dateTokens[2]);                                                                             // 373
                                                                                                                      //
			Employees.update({ _id: entry._id }, { $set: {                                                                     // 375
					employeeFirstName: employeeFirstName,                                                                            // 377
					employeeLastName: employeeLastName,                                                                              // 378
					employeeStartDate: new Date(dateYear, dateMonth, dateDay),                                                       // 379
					employeeEndDate: null,                                                                                           // 380
					employeeExperience: employeeExperience,                                                                          // 381
					employeeHourlyRate: employeeHourlyRate                                                                           // 382
				} });                                                                                                             // 376
		}                                                                                                                   // 384
                                                                                                                      //
		return editEmployee;                                                                                                // 1
	}(),                                                                                                                 // 1
	deleteEmployee: function () {                                                                                        // 386
		function deleteEmployee(employee) {                                                                                 // 1
			if (!Meteor.userId()) {                                                                                            // 387
				throw new Meteor.Error('You must be logged in.');                                                                 // 388
			}                                                                                                                  // 389
			Employees.remove(employee._id);                                                                                    // 390
		}                                                                                                                   // 391
                                                                                                                      //
		return deleteEmployee;                                                                                              // 1
	}(),                                                                                                                 // 1
	addCustomer: function () {                                                                                           // 393
		function addCustomer(customerId, contactName, address, billableOwner, billableAddress, phone1, phone2, email, qsp, comments, nextService) {
			if (!Meteor.userId()) {                                                                                            // 396
				throw new Meteor.Error('You must be logged in.');                                                                 // 397
			}                                                                                                                  // 398
			entry = Customers.findOne({ customerId: parseInt(customerId) });                                                   // 399
			if (entry) {                                                                                                       // 400
				throw new Meteor.Error('Duplicate id');                                                                           // 401
			}                                                                                                                  // 402
			var dateTokens = nextService.split("-");                                                                           // 403
			var dateYear = parseInt(dateTokens[0]);                                                                            // 404
			var dateMonth = parseInt(dateTokens[1]) - 1; //BSON month is 0 based                                               // 405
			var dateDay = parseInt(dateTokens[2]);                                                                             // 406
                                                                                                                      //
			Customers.insert({                                                                                                 // 409
				customerId: customerId,                                                                                           // 410
				contactName: contactName,                                                                                         // 411
				address: address,                                                                                                 // 412
				billableOwner: billableOwner,                                                                                     // 413
				billableAddress: billableAddress,                                                                                 // 414
				phone1: phone1,                                                                                                   // 415
				phone2: phone2,                                                                                                   // 416
				email: email,                                                                                                     // 417
				qsp: qsp,                                                                                                         // 418
				comments: comments,                                                                                               // 419
				nextService: new Date(dateYear, dateMonth, dateDay),                                                              // 420
				createdAt: new Date()                                                                                             // 421
			});                                                                                                                // 409
		}                                                                                                                   // 423
                                                                                                                      //
		return addCustomer;                                                                                                 // 1
	}(),                                                                                                                 // 1
	editCustomer: function () {                                                                                          // 425
		function editCustomer(customer, contactName, address, billableOwner, billableAddress, phone1, phone2, email, qsp, comments, nextService) {
			if (!Meteor.userId()) {                                                                                            // 428
				throw new Meteor.Error('You must be logged in.');                                                                 // 429
			}                                                                                                                  // 430
			entry = Customers.findOne({ _id: customer._id });                                                                  // 431
			var dateTokens = nextService.split("-");                                                                           // 432
			var dateYear = parseInt(dateTokens[0]);                                                                            // 433
			var dateMonth = parseInt(dateTokens[1]) - 1; //BSON month is 0 based                                               // 434
			var dateDay = parseInt(dateTokens[2]);                                                                             // 435
			if (entry) {                                                                                                       // 436
				Customers.update({ _id: entry._id }, { $set: {                                                                    // 437
						contactName: contactName,                                                                                       // 440
						address: address,                                                                                               // 441
						billableOwner: billableOwner,                                                                                   // 442
						billableAddress: billableAddress,                                                                               // 443
						phone1: phone1,                                                                                                 // 444
						phone2: phone2,                                                                                                 // 445
						email: email,                                                                                                   // 446
						qsp: qsp,                                                                                                       // 447
						comments: comments,                                                                                             // 448
						nextService: new Date(dateYear, dateMonth, dateDay)                                                             // 449
					} });                                                                                                            // 439
			} else {                                                                                                           // 452
				throw new Meteor.Error('Invalid ID');                                                                             // 453
			}                                                                                                                  // 454
		}                                                                                                                   // 455
                                                                                                                      //
		return editCustomer;                                                                                                // 1
	}(),                                                                                                                 // 1
	deleteCustomer: function () {                                                                                        // 457
		function deleteCustomer(customer) {                                                                                 // 1
			//can only delete vehicles user inserted                                                                           // 458
			//might have to change                                                                                             // 459
			if (!Meteor.userId()) {                                                                                            // 460
				throw new Meteor.Error('You must be logged in.');                                                                 // 461
			}                                                                                                                  // 462
			Customers.remove(customer._id);                                                                                    // 463
		}                                                                                                                   // 464
                                                                                                                      //
		return deleteCustomer;                                                                                              // 1
	}()                                                                                                                  // 1
});                                                                                                                   // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publish.js                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Inventory = new Mongo.Collection("inventory");                                                                        // 1
Jobs = new Mongo.Collection("jobs");                                                                                  // 2
Vehicles = new Mongo.Collection("vehicles");                                                                          // 3
Employees = new Mongo.Collection("employees");                                                                        // 4
Customers = new Mongo.Collection("customers");                                                                        // 5
                                                                                                                      //
Meteor.publish("allInventory", function () {                                                                          // 8
	return Inventory.find();                                                                                             // 9
});                                                                                                                   // 10
                                                                                                                      //
Meteor.publish("queryInventory", function (query) {                                                                   // 12
	return Inventory.find({ inventoryItemName: query });                                                                 // 13
});                                                                                                                   // 14
                                                                                                                      //
Meteor.publish("allJobs", function () {                                                                               // 16
	return Jobs.find();                                                                                                  // 17
});                                                                                                                   // 18
                                                                                                                      //
Meteor.publish("allVehicles", function () {                                                                           // 20
	return Vehicles.find();                                                                                              // 21
});                                                                                                                   // 22
                                                                                                                      //
Meteor.publish("allEmployees", function () {                                                                          // 24
	return Employees.find();                                                                                             // 25
});                                                                                                                   // 26
                                                                                                                      //
Meteor.publish("allCustomers", function () {                                                                          // 28
	return Customers.find();                                                                                             // 29
});                                                                                                                   // 30
                                                                                                                      //
Meteor.publish("dateRangeJobs", function (startDate, endDate) {                                                       // 32
	return Jobs.find({                                                                                                   // 33
		date: {                                                                                                             // 34
			$gte: startDate,                                                                                                   // 35
			$lt: endDate                                                                                                       // 36
		}                                                                                                                   // 34
	});                                                                                                                  // 33
});                                                                                                                   // 39
                                                                                                                      //
Meteor.publish("allUsers", function () {                                                                              // 41
	return Meteor.users.find();                                                                                          // 42
});                                                                                                                   // 43
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":["meteor/meteor",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});                                           // 1
                                                                                                                      //
Meteor.startup(function () {                                                                                          // 3
                                                                                                                      //
	if (Meteor.users.find().count() === 0) {                                                                             // 5
		var id = Accounts.createUser({                                                                                      // 6
			password: 'admin',                                                                                                 // 7
			username: 'admin'                                                                                                  // 8
		});                                                                                                                 // 6
		Roles.setUserRoles(id, ['admin']);                                                                                  // 10
	}                                                                                                                    // 11
                                                                                                                      //
	Accounts.config({                                                                                                    // 13
		forbidClientAccountCreation: true                                                                                   // 14
                                                                                                                      //
	});                                                                                                                  // 13
                                                                                                                      //
	if (Employees.find().count() === 0) {                                                                                // 20
                                                                                                                      //
		var yearRandom = Math.floor(Math.random() * 17 + 2000);                                                             // 22
		var monthRandom = Math.floor(Math.random() * 12);                                                                   // 23
		var dayRandom = Math.floor(Math.random() * 32 + 1);                                                                 // 24
		var firstNameArray = ['Ted', 'Eddie', 'Bill', 'John', 'Tomas', 'Bobby'];                                            // 25
		var lastNameArray = ['Johnson', 'Adams', 'Martinez', 'Smith', 'Jones', 'Taylor'];                                   // 26
                                                                                                                      //
		for (i = 0; i < firstNameArray.length; ++i) {                                                                       // 28
			Employees.insert({                                                                                                 // 29
				employeeId: i + 1,                                                                                                // 30
				employeeFirstName: firstNameArray[i],                                                                             // 31
				employeeLastName: lastNameArray[i],                                                                               // 32
				employeeStartDate: new Date(yearRandom, monthRandom, dayRandom),                                                  // 33
				employeeExperience: 2017 - yearRandom + Math.floor(Math.random() * 20),                                           // 34
				employeeHourlyRate: Math.floor(Math.random() * 3 * 5) + 15,                                                       // 35
				createdAt: new Date()                                                                                             // 36
			});                                                                                                                // 29
		}                                                                                                                   // 38
	}                                                                                                                    // 40
                                                                                                                      //
	if (Jobs.find().count() === 0) {                                                                                     // 42
		var jobTypeArray = ['a', 'b', 'c'];                                                                                 // 43
		var vehicleIdArray = ['aaa123', 'bbb234', 'ccc345', 'ddd456'];                                                      // 44
                                                                                                                      //
		for (i = 1; i < 1000; i++) {                                                                                        // 46
			var addressRandom = Math.floor(Math.random() * 550);                                                               // 47
			var phoneRnd = Math.floor(Math.random() * 899 + 100) + '-' + Math.floor(Math.random() * 8999 + 1000);              // 48
			var _firstNameArray = ['Ted', 'Eddie', 'Bill', 'John', 'Tomas', 'Bobby'];                                          // 49
			var jobTypeRandom = Math.floor(Math.random() * 3);                                                                 // 50
			var _monthRandom = Math.floor(Math.random() * 12);                                                                 // 51
			var _dayRandom = Math.floor(Math.random() * 32 + 1);                                                               // 52
			var estimateRandom = parseFloat(parseFloat(Math.random() * 10000).toFixed(2));                                     // 53
			var costRandom = parseFloat(parseFloat(Math.max(100, estimateRandom + (Math.random() * 1000 - 500))).toFixed(2));  // 54
			var employeeRandom = Math.floor(Math.random() * 6 + 1);                                                            // 55
			var vehicleIdRandom = Math.floor(Math.random() * 4);                                                               // 56
			var milageRandom = Math.floor(Math.random() * 50 + 1);                                                             // 57
			var randomIds = [Math.floor(Math.random() * 40), Math.floor(Math.random() * 40), Math.floor(Math.random() * 40)];  // 58
			var randomCust = Math.floor(Math.random() * 40);                                                                   // 59
			var randomQts = [Math.floor(Math.random() * 3 + 1), Math.floor(Math.random() * 3 + 1), Math.floor(Math.random() * 3 + 1)];
                                                                                                                      //
			Jobs.insert({                                                                                                      // 62
				invoice: i,                                                                                                       // 63
				date: new Date(2017, _monthRandom, _dayRandom),                                                                   // 64
				customer: randomCust,                                                                                             // 65
				cName: 'McDonnel Miller #' + i,                                                                                   // 66
				cAddr: addressRandom + ' Ez Street',                                                                              // 67
				cPhn1: '(204)-' + phoneRnd,                                                                                       // 68
				cPhn2: '',                                                                                                        // 69
				jobTypeCode: jobTypeArray[jobTypeRandom],                                                                         // 70
				estimateCost: estimateRandom,                                                                                     // 71
				estimateParts: {},                                                                                                // 72
				estimateEmployee: employeeRandom,                                                                                 // 73
				installCost: costRandom,                                                                                          // 74
				installParts: {},                                                                                                 // 75
				installations: [{ key: 'installItem0', item: randomIds[0], quantity: randomQts[0] }, { key: 'installItem1', item: randomIds[1], quantity: randomQts[1] }, { key: 'installItem2', item: randomIds[2], quantity: randomQts[2] }],
				installEmployee: employeeRandom,                                                                                  // 79
				empName: _firstNameArray[employeeRandom - 1],                                                                     // 80
				vehicleId: vehicleIdArray[vehicleIdRandom],                                                                       // 81
				mileage: milageRandom,                                                                                            // 82
				complete: false,                                                                                                  // 83
				createdAt: new Date()                                                                                             // 84
                                                                                                                      //
			});                                                                                                                // 62
		}                                                                                                                   // 88
	}                                                                                                                    // 91
                                                                                                                      //
	if (Inventory.find().count() === 0) {                                                                                // 93
                                                                                                                      //
		for (i = 1; i < 40; i++) {                                                                                          // 95
			var quantityRandom = Math.floor(Math.random() * 50);                                                               // 96
			var modelNumRandom = parseFloat(parseFloat(Math.random() * 10000).toFixed(2));                                     // 97
			var serialNumRandom = parseFloat(parseFloat(Math.random() * 10000).toFixed(2));                                    // 98
			var _costRandom = parseFloat(parseFloat(Math.random() * 100).toFixed(2) + 50);                                     // 99
                                                                                                                      //
			Inventory.insert({                                                                                                 // 101
				inventoryItemId: i,                                                                                               // 102
				inventoryItemName: 'Placeholder Item',                                                                            // 103
				unitPrice: _costRandom,                                                                                           // 104
				inventoryItemQuantity: quantityRandom,                                                                            // 105
				make: 'Plaecholder Make',                                                                                         // 106
				model: modelNumRandom,                                                                                            // 107
				serialNum: serialNumRandom,                                                                                       // 108
				createdAt: new Date()                                                                                             // 109
                                                                                                                      //
			});                                                                                                                // 101
		}                                                                                                                   // 113
	}                                                                                                                    // 116
                                                                                                                      //
	if (Customers.find().count() === 0) {                                                                                // 118
                                                                                                                      //
		for (i = 1; i < 40; i++) {                                                                                          // 120
			var _addressRandom = Math.floor(Math.random() * 550);                                                              // 121
			var _phoneRnd = Math.floor(Math.random() * 899 + 100) + '-' + Math.floor(Math.random() * 8999 + 1000);             // 122
			var _monthRandom2 = Math.floor(Math.random() * 12);                                                                // 123
			var _dayRandom2 = Math.floor(Math.random() * 32 + 1);                                                              // 124
                                                                                                                      //
			Customers.insert({                                                                                                 // 126
				customerId: i,                                                                                                    // 127
				contactName: 'McDonnel Miller #' + i,                                                                             // 128
				address: _addressRandom + ' Ez Street',                                                                           // 129
				billableOwner: '',                                                                                                // 130
				billableAddress: '',                                                                                              // 131
				phone1: '(204)-' + _phoneRnd,                                                                                     // 132
				phone2: '',                                                                                                       // 133
				email: 'asdf@zxcv.com',                                                                                           // 134
				qsp: false,                                                                                                       // 135
				comments: 'Some additional information.',                                                                         // 136
				nextService: new Date(2017, _monthRandom2, _dayRandom2),                                                          // 137
				createdAt: new Date()                                                                                             // 138
                                                                                                                      //
			});                                                                                                                // 126
		}                                                                                                                   // 142
	}                                                                                                                    // 145
                                                                                                                      //
	if (Vehicles.find().count() === 0) {                                                                                 // 147
		Vehicles.insert({                                                                                                   // 148
			vehicleId: 1,                                                                                                      // 149
			vehicleName: 'Truck 1',                                                                                            // 150
			vehicleMake: 'Ford',                                                                                               // 151
			vehicleModel: 'F150',                                                                                              // 152
			vehicleModelYear: 2010,                                                                                            // 153
			licensePlate: 'ABC123',                                                                                            // 154
			color: 'Black',                                                                                                    // 155
			initialMileage: 76230,                                                                                             // 156
			createdAt: new Date()                                                                                              // 157
		});                                                                                                                 // 148
		Vehicles.insert({                                                                                                   // 159
			vehicleId: 2,                                                                                                      // 160
			vehicleName: 'Truck 2',                                                                                            // 161
			vehicleMake: 'Ford',                                                                                               // 162
			vehicleModel: 'F150',                                                                                              // 163
			vehicleModelYear: 2015,                                                                                            // 164
			licensePlate: 'ABC456',                                                                                            // 165
			color: 'Blue',                                                                                                     // 166
			initialMileage: 52553,                                                                                             // 167
			createdAt: new Date()                                                                                              // 168
		});                                                                                                                 // 159
		Vehicles.insert({                                                                                                   // 170
			vehicleId: 3,                                                                                                      // 171
			vehicleName: 'Truck 3',                                                                                            // 172
			vehicleMake: 'Ford',                                                                                               // 173
			vehicleModel: 'F250',                                                                                              // 174
			vehicleModelYear: 2010,                                                                                            // 175
			licensePlate: 'XYZ123',                                                                                            // 176
			color: 'Blue',                                                                                                     // 177
			initialMileage: 60439,                                                                                             // 178
			createdAt: new Date()                                                                                              // 179
		});                                                                                                                 // 170
		Vehicles.insert({                                                                                                   // 181
			vehicleId: 4,                                                                                                      // 182
			vehicleName: 'Truck 4',                                                                                            // 183
			vehicleMake: 'Toyota',                                                                                             // 184
			vehicleModel: 'Tundra',                                                                                            // 185
			vehicleModelYear: 2013,                                                                                            // 186
			licensePlate: 'XYZ456',                                                                                            // 187
			color: 'White',                                                                                                    // 188
			initialMileage: 14325,                                                                                             // 189
			createdAt: new Date()                                                                                              // 190
		});                                                                                                                 // 181
	}                                                                                                                    // 192
                                                                                                                      //
	if (Jobs.find().count() === 0) {                                                                                     // 194
		var _jobTypeArray = ['a', 'b', 'c'];                                                                                // 195
		var _vehicleIdArray = ['aaa123', 'bbb234', 'ccc345', 'ddd456'];                                                     // 196
                                                                                                                      //
		for (i = 1; i < 50; i++) {                                                                                          // 198
			var _jobTypeRandom = Math.floor(Math.random() * 3);                                                                // 199
			var _monthRandom3 = Math.floor(Math.random() * 12);                                                                // 200
			var _dayRandom3 = Math.floor(Math.random() * 32 + 1);                                                              // 201
			var _estimateRandom = parseFloat(parseFloat(Math.random() * 10000).toFixed(2));                                    // 202
			var _costRandom2 = parseFloat(parseFloat(Math.max(100, _estimateRandom + (Math.random() * 1000 - 500))).toFixed(2));
			var _employeeRandom = Math.floor(Math.random() * 6 + 1);                                                           // 204
			var _vehicleIdRandom = Math.floor(Math.random() * 4);                                                              // 205
			var _milageRandom = Math.floor(Math.random() * 50 + 1);                                                            // 206
			var _randomIds = [Math.floor(Math.random() * 40), Math.floor(Math.random() * 40), Math.floor(Math.random() * 40)];
			var _randomCust = Math.floor(Math.random() * 40);                                                                  // 208
			var _randomQts = [Math.floor(Math.random() * 3 + 1), Math.floor(Math.random() * 3 + 1), Math.floor(Math.random() * 3 + 1)];
			cust = Customers.findOne({ customerId: parseInt(_randomCust) });                                                   // 210
			emp = Employees.findOne({ employeeId: parseInt(_employeeRandom) });                                                // 211
			Jobs.insert({                                                                                                      // 212
				invoice: i,                                                                                                       // 213
				complete: false,                                                                                                  // 214
				date: new Date(2017, _monthRandom3, _dayRandom3),                                                                 // 215
				customer: _randomCust,                                                                                            // 216
				cName: cust.contactName,                                                                                          // 217
				cAddr: cust.address,                                                                                              // 218
				cPhn1: cust.phone1,                                                                                               // 219
				cPhn2: cust.phone2,                                                                                               // 220
				jobTypeCode: _jobTypeArray[_jobTypeRandom],                                                                       // 221
				estimateCost: _estimateRandom,                                                                                    // 222
				estimateParts: {},                                                                                                // 223
				estimateEmployee: _employeeRandom,                                                                                // 224
				empName: emp.employeeFirstName,                                                                                   // 225
				installCost: _costRandom2,                                                                                        // 226
				installParts: {},                                                                                                 // 227
				installations: [{ key: 'installItem0', item: _randomIds[0], quantity: _randomQts[0] }, { key: 'installItem1', item: _randomIds[1], quantity: _randomQts[1] }, { key: 'installItem2', item: _randomIds[2], quantity: _randomQts[2] }],
				installEmployee: _employeeRandom,                                                                                 // 231
				vehicleId: _vehicleIdRandom,                                                                                      // 232
				mileage: _milageRandom,                                                                                           // 233
				comments: "Worst. Job. Ever!",                                                                                    // 234
				createdAt: new Date()                                                                                             // 235
                                                                                                                      //
			});                                                                                                                // 212
		}                                                                                                                   // 239
	}                                                                                                                    // 242
});                                                                                                                   // 244
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/methods.js");
require("./server/publish.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
