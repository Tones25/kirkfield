var require = meteorInstall({"server":{"methods.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/methods.js                                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Meteor.methods({                                                                                                     // 1
	addInventoryItem: function () {                                                                                     // 3
		function addInventoryItem(inventoryItemId, inventoryItemName, unitPrice, inventoryItemQuantity, make, model, serialNum) {
			if (!Meteor.userId()) {                                                                                           // 4
				throw new Meteor.Error('You must be logged in.');                                                                // 5
			}                                                                                                                 // 6
                                                                                                                     //
			entry = Inventory.findOne({ inventoryItemId: inventoryItemId });                                                  // 8
			//update quantity if item exists, add new listing if not                                                          // 9
			if (entry) {                                                                                                      // 10
				newQuantity = parseInt(entry.inventoryItemQuantity) + parseInt(inventoryItemQuantity);                           // 11
				Inventory.update({ _id: entry._id }, { $set: { inventoryItemQuantity: newQuantity } });                          // 12
			} else {                                                                                                          // 16
				Inventory.insert({                                                                                               // 17
					inventoryItemId: inventoryItemId,                                                                               // 18
					inventoryItemName: inventoryItemName,                                                                           // 19
					unitPrice: parseFloat(unitPrice),                                                                               // 20
					inventoryItemQuantity: parseInt(inventoryItemQuantity),                                                         // 21
					make: make,                                                                                                     // 22
					model: model,                                                                                                   // 23
					serialNum: serialNum,                                                                                           // 24
					createdAt: new Date(),                                                                                          // 25
					user: Meteor.userId()                                                                                           // 26
				});                                                                                                              // 17
			}                                                                                                                 // 28
		}                                                                                                                  // 29
                                                                                                                     //
		return addInventoryItem;                                                                                           // 1
	}(),                                                                                                                // 1
	editInventoryItem: function () {                                                                                    // 31
		function editInventoryItem(inventoryItem, inventoryItemName, unitPrice, inventoryItemQuantity, make, model, serialNum) {
			if (!Meteor.userId()) {                                                                                           // 32
				throw new Meteor.Error('You must be logged in.');                                                                // 33
			}                                                                                                                 // 34
			entry = Inventory.findOne({ _id: inventoryItem._id });                                                            // 35
			if (entry) {                                                                                                      // 36
				Inventory.update({ _id: entry._id }, { $set: {                                                                   // 37
						inventoryItemName: inventoryItemName,                                                                          // 40
						unitPrice: unitPrice,                                                                                          // 41
						inventoryItemQuantity: inventoryItemQuantity,                                                                  // 42
						make: make,                                                                                                    // 43
						model: model,                                                                                                  // 44
						serialNum: serialNum                                                                                           // 45
					} });                                                                                                           // 39
			} else {                                                                                                          // 48
				throw new Meteor.Error('Invalid ID');                                                                            // 49
			}                                                                                                                 // 50
		}                                                                                                                  // 51
                                                                                                                     //
		return editInventoryItem;                                                                                          // 1
	}(),                                                                                                                // 1
	deleteInventoryItem: function () {                                                                                  // 53
		function deleteInventoryItem(inventoryItem) {                                                                      // 1
			//can only delete items user inserted                                                                             // 54
			//might have to change                                                                                            // 55
			if (!Meteor.userId()) {                                                                                           // 56
				throw new Meteor.Error('You must be logged in.');                                                                // 57
			}                                                                                                                 // 58
			Inventory.remove(inventoryItem._id);                                                                              // 59
		}                                                                                                                  // 60
                                                                                                                     //
		return deleteInventoryItem;                                                                                        // 1
	}(),                                                                                                                // 1
	addJob: function () {                                                                                               // 62
		function addJob(invoice, date, customer, jobTypeCode, estimateCost, estimateEmployee, installCost, installations, installEmployee, vehicleId, mileage) {
			if (!Meteor.userId()) {                                                                                           // 65
				throw new Meteor.Error('You must be logged in.');                                                                // 66
			}                                                                                                                 // 67
			entry = Jobs.findOne({ invoice: parseInt(invoice) });                                                             // 68
			if (entry) {                                                                                                      // 69
				throw new Meteor.Error('Duplicate invoice');                                                                     // 70
			}                                                                                                                 // 71
			var dateTokens = date.split("-");                                                                                 // 72
			var dateYear = parseInt(dateTokens[0]);                                                                           // 73
			var dateMonth = parseInt(dateTokens[1]) - 1; //BSON month is 0 based                                              // 74
			var dateDay = parseInt(dateTokens[2]);                                                                            // 75
                                                                                                                     //
			Jobs.insert({                                                                                                     // 77
				invoice: parseInt(invoice),                                                                                      // 78
				date: new Date(dateYear, dateMonth, dateDay),                                                                    // 79
				customer: customer,                                                                                              // 80
				jobTypeCode: jobTypeCode,                                                                                        // 81
				estimateCost: parseFloat(estimateCost),                                                                          // 82
				estimateEmployee: parseInt(estimateEmployee),                                                                    // 83
				installCost: parseFloat(installCost),                                                                            // 84
				installations: installations,                                                                                    // 85
				installEmployee: parseInt(installEmployee),                                                                      // 86
				vehicleId: vehicleId,                                                                                            // 87
				mileage: parseInt(mileage),                                                                                      // 88
				complete: false,                                                                                                 // 89
				createdAt: new Date(),                                                                                           // 90
				user: Meteor.userId()                                                                                            // 91
			});                                                                                                               // 77
			//Decrease stock quantity of job's installed items                                                                // 93
			if (installations[0].item) {                                                                                      // 94
				for (var i = 0; i < installations.length; i++) {                                                                 // 95
					entry = Inventory.findOne({ inventoryItemId: parseInt(installations[i].item) });                                // 96
					//console.log(installQts[i])                                                                                    // 97
					var quant = installations[i].quantity || 1;                                                                     // 98
					//console.log(quant)                                                                                            // 99
					newQuantity = entry.inventoryItemQuantity - quant;                                                              // 100
					Inventory.update({ _id: entry._id }, { $set: { inventoryItemQuantity: newQuantity } });                         // 101
				}                                                                                                                // 105
			}                                                                                                                 // 106
		}                                                                                                                  // 107
                                                                                                                     //
		return addJob;                                                                                                     // 1
	}(),                                                                                                                // 1
	editJobItem: function () {                                                                                          // 109
		function editJobItem(job, date, customer, jobTypeCode, estimateCost, estimateEmployee, installCost, installations, installEmployee, vehicleId, mileage) {
			if (!Meteor.userId()) {                                                                                           // 112
				throw new Meteor.Error('You must be logged in.');                                                                // 113
			}                                                                                                                 // 114
			entry = Jobs.findOne({ _id: job._id });                                                                           // 115
			if (entry) {                                                                                                      // 116
				var dateTokens = date.split("-");                                                                                // 117
				var dateYear = parseInt(dateTokens[0]);                                                                          // 118
				var dateMonth = parseInt(dateTokens[1]) - 1; //BSON month is 0 based                                             // 119
				var dateDay = parseInt(dateTokens[2]);                                                                           // 120
				Jobs.update({ _id: entry._id }, { $set: {                                                                        // 121
						date: new Date(dateYear, dateMonth, dateDay),                                                                  // 124
						customer: customer,                                                                                            // 125
						jobTypeCode: jobTypeCode,                                                                                      // 126
						estimateCost: parseFloat(estimateCost),                                                                        // 127
						estimateEmployee: parseInt(estimateEmployee),                                                                  // 128
						installCost: parseFloat(installCost),                                                                          // 129
						installations: installations,                                                                                  // 130
						installEmployee: parseInt(installEmployee),                                                                    // 131
						vehicleId: vehicleId,                                                                                          // 132
						mileage: parseInt(mileage),                                                                                    // 133
						complete: false                                                                                                // 134
					} });                                                                                                           // 123
			} else {                                                                                                          // 135
				throw new Meteor.Error('Invalid ID');                                                                            // 136
			}                                                                                                                 // 137
		}                                                                                                                  // 138
                                                                                                                     //
		return editJobItem;                                                                                                // 1
	}(),                                                                                                                // 1
	deleteJobItem: function () {                                                                                        // 140
		function deleteJobItem(job) {                                                                                      // 1
			if (!Meteor.userId()) {                                                                                           // 141
				throw new Meteor.Error('You must be logged in.');                                                                // 142
			}                                                                                                                 // 143
			var installIds = job.installIds;                                                                                  // 144
			var installQts = job.installQts;                                                                                  // 145
			Jobs.remove(job._id);                                                                                             // 146
			//Restore stock quantity of the deleted job's installed items                                                     // 147
			for (var i = 0; i < installIds.length; i++) {                                                                     // 148
				entry = Inventory.findOne({ inventoryItemId: parseInt(installIds[i]) });                                         // 149
				//console.log(installQts[i])                                                                                     // 150
				var quant = parseInt(installQts[i]) || 1;                                                                        // 151
				//console.log(quant)                                                                                             // 152
				newQuantity = entry.inventoryItemQuantity + quant;                                                               // 153
				Inventory.update({ _id: entry._id }, { $set: { inventoryItemQuantity: newQuantity } });                          // 154
			}                                                                                                                 // 158
		}                                                                                                                  // 159
                                                                                                                     //
		return deleteJobItem;                                                                                              // 1
	}(),                                                                                                                // 1
	addVehicle: function () {                                                                                           // 161
		function addVehicle(vehicleId, vehicleMake, vehicleModel, vehicleModelYear, licensePlate, color, initialMileage, repairHist, description, lastOil, nextOil) {
			if (!Meteor.userId()) {                                                                                           // 165
				throw new Meteor.Error('You must be logged in.');                                                                // 166
			}                                                                                                                 // 167
			entry = Vehicles.findOne({ vehicleId: parseInt(vehicleId) });                                                     // 168
			if (entry) {                                                                                                      // 169
				throw new Meteor.Error('Duplicate id');                                                                          // 170
			}                                                                                                                 // 171
			var dateTokens = lastOil.split("-");                                                                              // 172
			var dateYear = parseInt(dateTokens[0]);                                                                           // 173
			var dateMonth = parseInt(dateTokens[1]) - 1; //BSON month is 0 based                                              // 174
			var dateDay = parseInt(dateTokens[2]);                                                                            // 175
			var lOil = new Date(dateYear, dateMonth, dateDay);                                                                // 176
			var dateTokens2 = nextOil.split("-");                                                                             // 177
			var dateYear2 = parseInt(dateTokens2[0]);                                                                         // 178
			var dateMonth2 = parseInt(dateTokens2[1]) - 1; //BSON month is 0 based                                            // 179
			var dateDay2 = parseInt(dateTokens2[2]);                                                                          // 180
			var nOil = new Date(dateYear2, dateMonth2, dateDay2);                                                             // 181
			Vehicles.insert({                                                                                                 // 182
				vehicleId: vehicleId,                                                                                            // 183
				vehicleMake: vehicleMake,                                                                                        // 184
				vehicleModel: vehicleModel,                                                                                      // 185
				vehicleModelYear: vehicleModelYear,                                                                              // 186
				licensePlate: licensePlate,                                                                                      // 187
				color: color,                                                                                                    // 188
				initialMileage: initialMileage,                                                                                  // 189
				description: description,                                                                                        // 190
				repairHist: repairHist,                                                                                          // 191
				lastOil: lOil,                                                                                                   // 192
				nextOil: nOil,                                                                                                   // 193
				createdAt: new Date(),                                                                                           // 194
				user: Meteor.userId()                                                                                            // 195
			});                                                                                                               // 182
		}                                                                                                                  // 197
                                                                                                                     //
		return addVehicle;                                                                                                 // 1
	}(),                                                                                                                // 1
	editVehicle: function () {                                                                                          // 199
		function editVehicle(vehicle, vehicleMake, vehicleModel, vehicleModelYear, licensePlate, color, initialMileage, repairHist, description, lastOil, nextOil) {
			if (!Meteor.userId()) {                                                                                           // 203
				throw new Meteor.Error('You must be logged in.');                                                                // 204
			}                                                                                                                 // 205
			entry = Vehicles.findOne({ _id: vehicle._id });                                                                   // 206
			if (entry) {                                                                                                      // 207
				var dateTokens = lastOil.split("-");                                                                             // 208
				var dateYear = parseInt(dateTokens[0]);                                                                          // 209
				var dateMonth = parseInt(dateTokens[1]) - 1; //BSON month is 0 based                                             // 210
				var dateDay = parseInt(dateTokens[2]);                                                                           // 211
				var lOil = new Date(dateYear, dateMonth, dateDay);                                                               // 212
				var dateTokens2 = nextOil.split("-");                                                                            // 213
				var dateYear2 = parseInt(dateTokens2[0]);                                                                        // 214
				var dateMonth2 = parseInt(dateTokens2[1]) - 1; //BSON month is 0 based                                           // 215
				var dateDay2 = parseInt(dateTokens2[2]);                                                                         // 216
				var nOil = new Date(dateYear2, dateMonth2, dateDay2);                                                            // 217
				Vehicles.update({ _id: entry._id }, { $set: {                                                                    // 218
						vehicleMake: vehicleMake,                                                                                      // 221
						vehicleModel: vehicleModel,                                                                                    // 222
						vehicleModelYear: vehicleModelYear,                                                                            // 223
						licensePlate: licensePlate,                                                                                    // 224
						color: color,                                                                                                  // 225
						initialMileage: initialMileage,                                                                                // 226
						description: description,                                                                                      // 227
						repairHist: repairHist,                                                                                        // 228
						lastOil: lOil,                                                                                                 // 229
						nextOil: nOil,                                                                                                 // 230
						createdAt: new Date(),                                                                                         // 231
						user: Meteor.userId()                                                                                          // 232
					} });                                                                                                           // 220
			}                                                                                                                 // 234
		}                                                                                                                  // 234
                                                                                                                     //
		return editVehicle;                                                                                                // 1
	}(),                                                                                                                // 1
	deleteVehicle: function () {                                                                                        // 236
		function deleteVehicle(vehicle) {                                                                                  // 1
			//can only delete vehicles user inserted                                                                          // 237
			//might have to change                                                                                            // 238
			if (!Meteor.userId()) {                                                                                           // 239
				throw new Meteor.Error('You must be logged in.');                                                                // 240
			}                                                                                                                 // 241
			Vehicles.remove(vehicle._id);                                                                                     // 242
		}                                                                                                                  // 243
                                                                                                                     //
		return deleteVehicle;                                                                                              // 1
	}(),                                                                                                                // 1
	addEmployee: function () {                                                                                          // 245
		function addEmployee(employeeId, employeeFirstName, employeeLastName, employeeStartDate, employeeExperience, employeeHourlyRate) {
			if (!Meteor.userId()) {                                                                                           // 247
				throw new Meteor.Error('You must be logged in.');                                                                // 248
			}                                                                                                                 // 249
			entry = Employees.findOne({ employeeId: parseInt(employeeId) });                                                  // 250
			if (entry) {                                                                                                      // 251
				throw new Meteor.Error('Duplicate id');                                                                          // 252
			}                                                                                                                 // 253
                                                                                                                     //
			Employees.insert({                                                                                                // 255
				employeeId: employeeId,                                                                                          // 256
				employeeFirstName: employeeFirstName,                                                                            // 257
				employeeLastName: employeeLastName,                                                                              // 258
				employeeStartDate: employeeStartDate,                                                                            // 259
				employeeEndDate: null,                                                                                           // 260
				employeeExperience: employeeExperience,                                                                          // 261
				employeeHourlyRate: employeeHourlyRate,                                                                          // 262
				createdAt: new Date(),                                                                                           // 263
				user: Meteor.userId()                                                                                            // 264
			});                                                                                                               // 255
		}                                                                                                                  // 266
                                                                                                                     //
		return addEmployee;                                                                                                // 1
	}(),                                                                                                                // 1
	deleteEmployee: function () {                                                                                       // 268
		function deleteEmployee(employee) {                                                                                // 1
			//can only delete vehicles user inserted                                                                          // 269
			//might have to change                                                                                            // 270
			if (Meteor.userId() !== employee.user) {                                                                          // 271
				throw new Meteor.Error('You must be logged in.');                                                                // 272
			}                                                                                                                 // 273
			Employees.remove(employee._id);                                                                                   // 274
		}                                                                                                                  // 275
                                                                                                                     //
		return deleteEmployee;                                                                                             // 1
	}(),                                                                                                                // 1
	addCustomer: function () {                                                                                          // 277
		function addCustomer(customerId, contactName, address, billableOwner, billableAddress, phone1, phone2, email, qsp, comments, nextService) {
			if (!Meteor.userId()) {                                                                                           // 280
				throw new Meteor.Error('You must be logged in.');                                                                // 281
			}                                                                                                                 // 282
			entry = Customers.findOne({ customerId: parseInt(customerId) });                                                  // 283
			if (entry) {                                                                                                      // 284
				throw new Meteor.Error('Duplicate id');                                                                          // 285
			}                                                                                                                 // 286
			var dateTokens = nextService.split("-");                                                                          // 287
			var dateYear = parseInt(dateTokens[0]);                                                                           // 288
			var dateMonth = parseInt(dateTokens[1]) - 1; //BSON month is 0 based                                              // 289
			var dateDay = parseInt(dateTokens[2]);                                                                            // 290
                                                                                                                     //
			Customers.insert({                                                                                                // 293
				customerId: customerId,                                                                                          // 294
				contactName: contactName,                                                                                        // 295
				address: address,                                                                                                // 296
				billableOwner: billableOwner,                                                                                    // 297
				billableAddress: billableAddress,                                                                                // 298
				phone1: phone1,                                                                                                  // 299
				phone2: phone2,                                                                                                  // 300
				email: email,                                                                                                    // 301
				qsp: qsp,                                                                                                        // 302
				comments: comments,                                                                                              // 303
				nextService: new Date(dateYear, dateMonth, dateDay),                                                             // 304
				createdAt: new Date()                                                                                            // 305
                                                                                                                     //
			});                                                                                                               // 293
		}                                                                                                                  // 308
                                                                                                                     //
		return addCustomer;                                                                                                // 1
	}(),                                                                                                                // 1
	editCustomer: function () {                                                                                         // 310
		function editCustomer(customer, contactName, address, billableOwner, billableAddress, phone1, phone2, email, qsp, comments, nextService) {
			if (!Meteor.userId()) {                                                                                           // 313
				throw new Meteor.Error('You must be logged in.');                                                                // 314
			}                                                                                                                 // 315
			entry = Customers.findOne({ _id: customer._id });                                                                 // 316
			var dateTokens = nextService.split("-");                                                                          // 317
			var dateYear = parseInt(dateTokens[0]);                                                                           // 318
			var dateMonth = parseInt(dateTokens[1]) - 1; //BSON month is 0 based                                              // 319
			var dateDay = parseInt(dateTokens[2]);                                                                            // 320
			if (entry) {                                                                                                      // 321
				Customers.update({ _id: entry._id }, { $set: {                                                                   // 322
						contactName: contactName,                                                                                      // 325
						address: address,                                                                                              // 326
						billableOwner: billableOwner,                                                                                  // 327
						billableAddress: billableAddress,                                                                              // 328
						phone1: phone1,                                                                                                // 329
						phone2: phone2,                                                                                                // 330
						email: email,                                                                                                  // 331
						qsp: qsp,                                                                                                      // 332
						comments: comments,                                                                                            // 333
						nextService: new Date(dateYear, dateMonth, dateDay)                                                            // 334
					} });                                                                                                           // 324
			} else {                                                                                                          // 337
				throw new Meteor.Error('Invalid ID');                                                                            // 338
			}                                                                                                                 // 339
		}                                                                                                                  // 340
                                                                                                                     //
		return editCustomer;                                                                                               // 1
	}(),                                                                                                                // 1
	deleteCustomer: function () {                                                                                       // 342
		function deleteCustomer(customer) {                                                                                // 1
			//can only delete vehicles user inserted                                                                          // 343
			//might have to change                                                                                            // 344
			if (!Meteor.userId()) {                                                                                           // 345
				throw new Meteor.Error('You must be logged in.');                                                                // 346
			}                                                                                                                 // 347
			Customers.remove(customer._id);                                                                                   // 348
		}                                                                                                                  // 349
                                                                                                                     //
		return deleteCustomer;                                                                                             // 1
	}()                                                                                                                 // 1
});                                                                                                                  // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/publish.js                                                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Inventory = new Mongo.Collection("inventory");                                                                       // 1
Jobs = new Mongo.Collection("jobs");                                                                                 // 2
Vehicles = new Mongo.Collection("vehicles");                                                                         // 3
Employees = new Mongo.Collection("employees");                                                                       // 4
Customers = new Mongo.Collection("customers");                                                                       // 5
                                                                                                                     //
Meteor.publish("allInventory", function () {                                                                         // 7
	return Inventory.find();                                                                                            // 8
});                                                                                                                  // 9
                                                                                                                     //
Meteor.publish("queryInventory", function (query) {                                                                  // 11
	return Inventory.find({ inventoryItemName: query });                                                                // 12
});                                                                                                                  // 13
                                                                                                                     //
Meteor.publish("allJobs", function () {                                                                              // 15
	return Jobs.find();                                                                                                 // 16
});                                                                                                                  // 17
                                                                                                                     //
Meteor.publish("allVehicles", function () {                                                                          // 19
	return Vehicles.find();                                                                                             // 20
});                                                                                                                  // 21
                                                                                                                     //
Meteor.publish("allEmployees", function () {                                                                         // 23
	return Employees.find();                                                                                            // 24
});                                                                                                                  // 25
                                                                                                                     //
Meteor.publish("allCustomers", function () {                                                                         // 27
	return Customers.find();                                                                                            // 28
});                                                                                                                  // 29
                                                                                                                     //
Meteor.publish("dateRangeJobs", function (startDate, endDate) {                                                      // 31
	return Jobs.find({                                                                                                  // 32
		date: {                                                                                                            // 33
			$gte: startDate,                                                                                                  // 34
			$lt: endDate                                                                                                      // 35
		}                                                                                                                  // 33
	});                                                                                                                 // 32
});                                                                                                                  // 38
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":["meteor/meteor",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/main.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});                                          // 1
                                                                                                                     //
Meteor.startup(function () {                                                                                         // 3
	if (Employees.find().count() === 0) {                                                                               // 4
                                                                                                                     //
		var yearRandom = Math.floor(Math.random() * 17 + 2000);                                                            // 6
		var monthRandom = Math.floor(Math.random() * 12);                                                                  // 7
		var dayRandom = Math.floor(Math.random() * 32 + 1);                                                                // 8
		var firstNameArray = ['Ted', 'Eddie', 'Bill', 'John', 'Tomas', 'Bobby'];                                           // 9
		var lastNameArray = ['Johnson', 'Adams', 'Martinez', 'Smith', 'Jones', 'Taylor'];                                  // 10
                                                                                                                     //
		for (i = 0; i < firstNameArray.length; ++i) {                                                                      // 12
			Employees.insert({                                                                                                // 13
				employeeId: i + 1,                                                                                               // 14
				employeeFirstName: firstNameArray[i],                                                                            // 15
				employeeLastName: lastNameArray[i],                                                                              // 16
				employeeStartDate: new Date(yearRandom, monthRandom, dayRandom),                                                 // 17
				employeeExperience: 2017 - yearRandom + Math.floor(Math.random() * 20),                                          // 18
				employeeHourlyRate: Math.floor(Math.random() * 3 * 5) + 15,                                                      // 19
				createdAt: new Date()                                                                                            // 20
			});                                                                                                               // 13
		}                                                                                                                  // 22
	}                                                                                                                   // 24
                                                                                                                     //
	if (Jobs.find().count() === 0) {                                                                                    // 26
		var jobTypeArray = ['a', 'b', 'c'];                                                                                // 27
		var vehicleIdArray = ['aaa123', 'bbb234', 'ccc345', 'ddd456'];                                                     // 28
                                                                                                                     //
		for (i = 1; i < 50; i++) {                                                                                         // 30
			var jobTypeRandom = Math.floor(Math.random() * 3);                                                                // 31
			var _monthRandom = Math.floor(Math.random() * 12);                                                                // 32
			var _dayRandom = Math.floor(Math.random() * 32 + 1);                                                              // 33
			var estimateRandom = parseFloat(parseFloat(Math.random() * 10000).toFixed(2));                                    // 34
			var costRandom = parseFloat(parseFloat(Math.max(100, estimateRandom + (Math.random() * 1000 - 500))).toFixed(2));
			var employeeRandom = Math.floor(Math.random() * 6 + 1);                                                           // 36
			var vehicleIdRandom = Math.floor(Math.random() * 4);                                                              // 37
			var milageRandom = Math.floor(Math.random() * 50 + 1);                                                            // 38
			var randomIds = [Math.floor(Math.random() * 40), Math.floor(Math.random() * 40), Math.floor(Math.random() * 40)];
			var randomCust = Math.floor(Math.random() * 40);                                                                  // 40
			var randomQts = [Math.floor(Math.random() * 3 + 1), Math.floor(Math.random() * 3 + 1), Math.floor(Math.random() * 3 + 1)];
                                                                                                                     //
			Jobs.insert({                                                                                                     // 43
				invoice: i,                                                                                                      // 44
				date: new Date(2017, _monthRandom, _dayRandom),                                                                  // 45
				customer: randomCust,                                                                                            // 46
				jobTypeCode: jobTypeArray[jobTypeRandom],                                                                        // 47
				estimateCost: estimateRandom,                                                                                    // 48
				estimateParts: {},                                                                                               // 49
				estimateEmployee: employeeRandom,                                                                                // 50
				installCost: costRandom,                                                                                         // 51
				installParts: {},                                                                                                // 52
				installations: [{ key: 'installItem0', item: randomIds[0], quantity: randomQts[0] }, { key: 'installItem1', item: randomIds[1], quantity: randomQts[1] }, { key: 'installItem2', item: randomIds[2], quantity: randomQts[2] }],
				installEmployee: employeeRandom,                                                                                 // 56
				vehicleId: vehicleIdArray[vehicleIdRandom],                                                                      // 57
				mileage: milageRandom,                                                                                           // 58
				complete: false,                                                                                                 // 59
				createdAt: new Date()                                                                                            // 60
                                                                                                                     //
			});                                                                                                               // 43
		}                                                                                                                  // 64
	}                                                                                                                   // 67
                                                                                                                     //
	if (Inventory.find().count() === 0) {                                                                               // 69
                                                                                                                     //
		for (i = 1; i < 40; i++) {                                                                                         // 71
			var quantityRandom = Math.floor(Math.random() * 50);                                                              // 72
			var modelNumRandom = parseFloat(parseFloat(Math.random() * 10000).toFixed(2));                                    // 73
			var serialNumRandom = parseFloat(parseFloat(Math.random() * 10000).toFixed(2));                                   // 74
			var _costRandom = parseFloat(parseFloat(Math.random() * 100).toFixed(2) + 50);                                    // 75
                                                                                                                     //
			Inventory.insert({                                                                                                // 77
				inventoryItemId: i,                                                                                              // 78
				inventoryItemName: 'Placeholder Item',                                                                           // 79
				unitPrice: _costRandom,                                                                                          // 80
				inventoryItemQuantity: quantityRandom,                                                                           // 81
				make: 'Plaecholder Make',                                                                                        // 82
				model: modelNumRandom,                                                                                           // 83
				serialNum: serialNumRandom,                                                                                      // 84
				createdAt: new Date()                                                                                            // 85
                                                                                                                     //
			});                                                                                                               // 77
		}                                                                                                                  // 89
	}                                                                                                                   // 92
                                                                                                                     //
	if (Customers.find().count() === 0) {                                                                               // 94
                                                                                                                     //
		for (i = 1; i < 40; i++) {                                                                                         // 96
			var addressRandom = Math.floor(Math.random() * 550);                                                              // 97
			var phoneRnd = Math.floor(Math.random() * 899 + 100) + '-' + Math.floor(Math.random() * 8999 + 1000);             // 98
			var _monthRandom2 = Math.floor(Math.random() * 12);                                                               // 99
			var _dayRandom2 = Math.floor(Math.random() * 32 + 1);                                                             // 100
                                                                                                                     //
			Customers.insert({                                                                                                // 102
				customerId: i,                                                                                                   // 103
				contactName: 'McDonnel Miller #' + i,                                                                            // 104
				address: addressRandom + ' Ez Street',                                                                           // 105
				billableOwner: '',                                                                                               // 106
				billableAddress: '',                                                                                             // 107
				phone1: '(204)-' + phoneRnd,                                                                                     // 108
				phone2: '',                                                                                                      // 109
				email: 'asdf@zxcv.com',                                                                                          // 110
				qsp: false,                                                                                                      // 111
				comments: 'Some additional information.',                                                                        // 112
				nextService: new Date(2017, _monthRandom2, _dayRandom2),                                                         // 113
				createdAt: new Date()                                                                                            // 114
                                                                                                                     //
			});                                                                                                               // 102
		}                                                                                                                  // 118
	}                                                                                                                   // 121
                                                                                                                     //
	if (Vehicles.find().count() === 0) {                                                                                // 123
		Vehicles.insert({                                                                                                  // 124
			vehicleId: 1,                                                                                                     // 125
			vehicleName: 'Truck 1',                                                                                           // 126
			vehicleMake: 'Ford',                                                                                              // 127
			vehicleModel: 'F150',                                                                                             // 128
			vehicleModelYear: 2010,                                                                                           // 129
			licensePlate: 'ABC123',                                                                                           // 130
			color: 'Black',                                                                                                   // 131
			initialMileage: 76230,                                                                                            // 132
			createdAt: new Date()                                                                                             // 133
		});                                                                                                                // 124
		Vehicles.insert({                                                                                                  // 135
			vehicleId: 2,                                                                                                     // 136
			vehicleName: 'Truck 2',                                                                                           // 137
			vehicleMake: 'Ford',                                                                                              // 138
			vehicleModel: 'F150',                                                                                             // 139
			vehicleModelYear: 2015,                                                                                           // 140
			licensePlate: 'ABC456',                                                                                           // 141
			color: 'Blue',                                                                                                    // 142
			initialMileage: 52553,                                                                                            // 143
			createdAt: new Date()                                                                                             // 144
		});                                                                                                                // 135
		Vehicles.insert({                                                                                                  // 146
			vehicleId: 3,                                                                                                     // 147
			vehicleName: 'Truck 3',                                                                                           // 148
			vehicleMake: 'Ford',                                                                                              // 149
			vehicleModel: 'F250',                                                                                             // 150
			vehicleModelYear: 2010,                                                                                           // 151
			licensePlate: 'XYZ123',                                                                                           // 152
			color: 'Blue',                                                                                                    // 153
			initialMileage: 60439,                                                                                            // 154
			createdAt: new Date()                                                                                             // 155
		});                                                                                                                // 146
		Vehicles.insert({                                                                                                  // 157
			vehicleId: 4,                                                                                                     // 158
			vehicleName: 'Truck 4',                                                                                           // 159
			vehicleMake: 'Toyota',                                                                                            // 160
			vehicleModel: 'Tundra',                                                                                           // 161
			vehicleModelYear: 2013,                                                                                           // 162
			licensePlate: 'XYZ456',                                                                                           // 163
			color: 'White',                                                                                                   // 164
			initialMileage: 14325,                                                                                            // 165
			createdAt: new Date()                                                                                             // 166
		});                                                                                                                // 157
	}                                                                                                                   // 168
});                                                                                                                  // 170
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/methods.js");
require("./server/publish.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
